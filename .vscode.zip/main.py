from view import Menu

if __name__ == "__main__":
    menu = Menu()

    while True:
        menu.mostrar_menu_principal()
        break
